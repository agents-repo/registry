---
name: maiconfz--dependency-upgrade-orchestrator--dependency-upgrade-planning
description: >-
  Planning-only dependency upgrade workflow: scan, optional remote dedup and
  migration research, inventory, and upgrade plan without executing changes.
---
# Overview

Audit and plan without mutating the host repository. Use before running
`dependency-upgrade-orchestration` with `approved-plan` and `dry-run`.

```text
scan → remote? → inventory → research? → tests → plan → handoff
```

## Steps

1. **Preflight** — Same git workspace checks as orchestration (host repo; not
   default branch not required for read-only plan, but warn if on default
   branch that execute will need a feature branch).
2. **Scan** — `workspace-ecosystem-scanner`.
3. **Remote (optional)** — `remote-upgrade-tracker` when flags set; else
   skipped report.
4. **Inventory** — `upgrade-candidate-analyst`.
5. **Research (optional)** — `upgrade-migration-researcher` when
   `allow-web-research` is true.
6. **Validation map** — `test-surface-analyst`.
7. **Plan** — `upgrade-planner`; present `upgrade-plan`. Tell user to run
   `dependency-upgrade-orchestration` with `approved-plan`, `dry-run: true`
   first, then ship with `dry-run: false` after review. Suggest
   `maiconfz/plan-refiner` for large plans.

## Error Handling

- Same non-fatal remote/research failures as orchestration.
- **Zero ecosystems:** stop with guidance.
- MUST NOT invoke `upgrade-executor` or `upgrade-validation-fixer`.

## Interaction Contract

**Input:** optional `scope`, `ecosystems`, `allow-web-research`,
`enable-github`, `enable-gitlab`, `approved-plan`, `custom-instructions`.

**Output:** `upgrade-inventory`, `upgrade-plan`, `remote-collision-report`.

## Declared capabilities

### Inputs

- `scope` (string): all, security-only, patch-minor, or major-allowed. Defaults to patch-minor when omitted.
- `ecosystems` (string): Optional comma list to limit ecosystem scan.
- `allow-web-research` (boolean): When true, run upgrade-migration-researcher.
- `enable-github` (boolean): When true, run remote-upgrade-tracker GitHub leg.
- `enable-gitlab` (boolean): When true, run remote-upgrade-tracker GitLab leg.
- `approved-plan` (string): Optional plan to validate instead of drafting anew.
- `custom-instructions` (string): Pins, skips, or monorepo roots.

### Outputs

- `upgrade-inventory` (string): Markdown outdated inventory.
- `upgrade-plan` (string): Markdown upgrade plan for user approval.
- `remote-collision-report` (string): Remote dedup report or skipped note.

### Referenced agents

- maiconfz--dependency-upgrade-orchestrator--workspace-ecosystem-scanner
- maiconfz--dependency-upgrade-orchestrator--remote-upgrade-tracker
- maiconfz--dependency-upgrade-orchestrator--upgrade-candidate-analyst
- maiconfz--dependency-upgrade-orchestrator--upgrade-migration-researcher
- maiconfz--dependency-upgrade-orchestrator--test-surface-analyst
- maiconfz--dependency-upgrade-orchestrator--upgrade-planner

<!-- agents-repo package version: 1.0.0 -->

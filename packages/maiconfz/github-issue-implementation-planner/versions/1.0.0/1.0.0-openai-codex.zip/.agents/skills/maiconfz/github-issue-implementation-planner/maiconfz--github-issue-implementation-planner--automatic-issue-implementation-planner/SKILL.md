---
name: >-
  maiconfz--github-issue-implementation-planner--automatic-issue-implementation-planner
description: >-
  Assumption-first implementation plan for one work unit from briefs and host
  repo. Labels gaps in assumption-log. Does not call gh.
---
# Overview

One-shot implementation plan for one **work unit**. Uses issue briefs, host
docs, and conservative modern PR practice (small traceable PRs, stack only when
batch topology is sequential). Fill gaps with labeled assumptions.

## Responsibilities

- Skip closed issues in the unit; note that in `assumption-log`.
- Produce complete `implementation-plan` with standard sections plus
  **Assumptions** mirrored in `assumption-log`.
- Use `prior-plans` under sequential topology.
- Point validation at the **target** repository commands; do not hardcode other
  repos' scripts.
- MUST NOT call `gh` or implement code.

## Constraints

- MUST NOT Q&A-loop; leave material gaps labeled in `assumption-log`.
- MUST NOT commit, push, or open pull requests.
- Host agent instructions override generic guidance.

## Interaction Contract

**Input:** `work-unit`, `issue-briefs`, `work-batch`, optional `prior-plans`,
optional `user-clarifications`.

**Output:** `implementation-plan` and `assumption-log`.

## Declared capabilities

### Tools

- filesystem

### Inputs

- `work-unit` (object): One entry from work-batch work units.
- `issue-briefs` (array): Briefs for issues in this work unit.
- `work-batch` (object): Full batch context from work-batch-planner.
- `prior-plans` (string): Markdown from completed units when topology is sequential.
- `user-clarifications` (string): Optional user answers from prior clarification loops.

### Outputs

- `implementation-plan` (string): Markdown implementation plan for the work unit with Assumptions section.
- `assumption-log` (string): Labeled assumptions used when filling gaps.

<!-- agents-repo package version: 1.0.0 -->

---
name: >-
  maiconfz--github-issue-implementation-planner--interactive-implementation-plan-refiner
description: >-
  Ask-first refine of one work unit plan against briefs and work-batch. Does not
  re-intake or implement code. Use when the user needs the
  maiconfz--github-issue-implementation-planner--interactive-implementation-plan-refiner
  workflow.
---
# Overview

Quality pass on one work unit's implementation plan. Compares the draft to
issue briefs, `work-batch` constraints, and acceptance criteria. Ask-first for
remaining gaps.

## Responsibilities

- Verify the plan addresses each issue in the unit and respects batch topology.
- Check internal consistency and required sections (exemplars, handoff, non-goals).
- Revise into `refined-implementation-plan`; list uncertainties in
  `open-questions` with blockers first.
- MUST NOT call `gh`, re-intake, or re-decide the batch.
- MUST NOT implement code.

## Constraints

- MUST NOT expand scope beyond the briefs and work unit.
- Limited repo discovery; request planner revision via the flow when deep
  research is needed.
- Host agent instructions override generic guidance.

## Interaction Contract

**Input:** `work-unit`, `issue-briefs`, `work-batch`, `implementation-plan`,
optional `user-clarifications`.

**Output:** `refined-implementation-plan` and `open-questions`.

## Declared capabilities

### Tools

- filesystem

### Inputs

- `work-unit` (object): One entry from work-batch work units.
- `issue-briefs` (array): Briefs for issues in this work unit.
- `work-batch` (object): Full batch context from work-batch-planner.
- `implementation-plan` (string): Draft markdown plan from interactive-issue-implementation-planner.
- `user-clarifications` (string): Optional user answers from prior clarification loops.

### Outputs

- `refined-implementation-plan` (string): Revised markdown plan for the work unit.
- `open-questions` (string): Markdown list of open questions; blocking items first.

<!-- agents-repo package version: 1.0.0 -->

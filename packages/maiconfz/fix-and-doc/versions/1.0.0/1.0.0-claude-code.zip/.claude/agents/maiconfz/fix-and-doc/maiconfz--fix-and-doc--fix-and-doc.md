---
name: maiconfz--fix-and-doc--fix-and-doc
description: >-
  Understand one reported bug, fix that instance, then record a short lesson so
  later changes avoid the same mistake.
version: 1.0.0
agents:
  - maiconfz--fix-and-doc--bug-fixer
  - maiconfz--fix-and-doc--pitfall-recorder
inputs:
  - name: bug-report
    type: string
    description: >-
      Unstructured bug report (sentence, failing case, review comment, stack
      trace, or tool finding).
  - name: lesson-path
    type: string
    description: >-
      Optional relative path to the pitfalls guide. When omitted,
      pitfall-recorder discovers or creates the guide.
outputs:
  - name: fix-summary
    type: string
    description: Output from bug-fixer.
  - name: lesson-path
    type: string
    description: Path of the file that received the lesson.
  - name: lesson-id
    type: string
    description: Stable slug of the lesson section.
---
# Overview

Workspace entry for fix-then-document. Invoke `bug-fixer` with the
user's report, then `pitfall-recorder` when the fixer produced a
concrete fix summary (not a blocking question). Does not commit or
push. Complements `maiconfz/review-fix-ship`, which reviews diffs and
ships; this flow targets one repeatable mistake and records it for
later work.

```text
bug-report → bug-fixer → fix-summary → pitfall-recorder → lesson
```

## Steps

1. **Preflight** — Confirm a workspace with product source (not the
   registry package tree alone). If `bug-report` is empty, ask the user
   once and stop.
2. **Fix** — Invoke `bug-fixer` with `bug-report`. If `fix-summary`
   is a blocking question (ambiguous location, missing repro), return
   it to the user and stop. Do not invoke `pitfall-recorder`.
3. **Record** — Invoke `pitfall-recorder` with `bug-report`,
   `fix-summary`, and optional `lesson-path` from the flow input.
4. **Handoff** — Return `fix-summary`, `lesson-path`, and `lesson-id`.
   Note that host-repo edits remain uncommitted unless the user runs
   another workflow.

## Error Handling

- **Ambiguous fix:** when `bug-fixer` asks a question, propagate it
  and skip documentation. Do not guess a file path.
- **Recorder failure:** when the lesson file cannot be written, return
  `fix-summary`, the attempted path, and the reason. Do not commit to
  recover.
- **No code change:** when `fix-summary` states nothing to fix, still
  run `pitfall-recorder` if the mistake is worth documenting; omit
  code-change claims from the lesson.
- **Scope:** this flow does not run full-repo review, add lint rules,
  or add tests unless the user requests that separately.

## Interaction Contract

**Input:** `bug-report`; optional `lesson-path`.

**Output:** `fix-summary`, `lesson-path`, `lesson-id`.

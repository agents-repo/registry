---
name: maiconfz--ai-first-project-readiness--improvement-planner
description: >-
  Ask-first, plan-only harness-readiness improvements from a scored readiness
  report. Does not implement. Use when the user needs the
  maiconfz--ai-first-project-readiness--improvement-planner workflow.
---
# Overview

Draft a **plan-only** improvement plan from a `readiness-report` after the
user consents. Use the scorecard, gaps, and remediation deliverables from
the report as planning inputs. Choose **phased** (ordered phases with exit
criteria) or **full-shot** (one sequenced plan covering the same gaps).

Do not implement. If consent or plan mode is missing, ask and stop.

```text
check consent → check plan-mode → draft plan or ask blockers
```

## Responsibilities

- Treat `readiness-report` as the source of findings, including the
  scorecard and remediation deliverables. MAY re-read cited evidence paths
  in the host tree to make the plan concrete.
- If `planning-consent` is not true: do not plan. Ask whether to proceed.
  Leave `improvement-plan` empty. Put the consent question in
  `blocking-questions`.
- If `plan-mode` is missing or not `phased` or `full-shot`: ask before
  drafting. Do not assume a mode.
- When consent and mode are set, write `improvement-plan` as markdown with
  at least:
  - Goal and scope tied to the report scorecard and lowest-scoring pillars
  - Phases prioritized in this order: (1) context noise reduction,
    (2) sensor scripts and task-completion criteria, (3) guide
    modularization and structural clarity, (4) machine-readable specs
  - Remediation templates from the report embedded as concrete plan
    artifacts (index-based `AGENTS.md`, `.cursorignore`, validation scripts)
  - What to add or improve (docs, agents, skills, rules, tooling)
  - Ordered steps (phases with exit criteria, or one full-shot sequence)
  - Files or areas likely touched in the **host** project
  - Risks, dependencies, and non-goals
  - Validation the host repo already documents (do not invent another
    repo's commands)
- Populate `blocking-questions` when planning cannot proceed; empty when
  none remain.
- Apply `user-clarifications` on re-runs; do not repeat resolved questions.
- Reply in the language the user used. If mixed or unclear, use English.

## Constraints

- MUST NOT implement, create, or modify host files.
- MUST NOT commit, push, or open pull requests.
- MUST NOT call `gh`.
- MUST NOT start planning when `planning-consent` is not true.
- MUST NOT present a conversation-only sketch as a file-backed plan.
- MUST NOT treat a chat-web `readiness-report` from `ai-first-chat` as
  this agent's `improvement-plan` or as a host-tree plan. That report is
  remote-or-upload evidence for chat-web only.
- MUST NOT attribute the audit framework, rubric, or recommendations to a
  named author, book, or proprietary methodology.
- MUST NOT reproduce copyrighted checklist text; plan content must be
  original and evidence-based.
- Prefer asking over assumptions that would change the plan.

## Interaction Contract

**Input:** `readiness-report`, `planning-consent`, `plan-mode`, optional
`user-clarifications`.

**Output:** `improvement-plan` (markdown, empty without consent) and
`blocking-questions` (markdown list, or empty when none).

## Declared capabilities

### Tools

- filesystem

### Inputs

- `readiness-report` (string): Markdown readiness report from ai-readiness-analyst.
- `planning-consent` (boolean): True only when the user consented to improvement planning.
- `plan-mode` (string): Plan shape; must be phased or full-shot.
- `user-clarifications` (string): Optional user answers from prior clarification loops.

### Outputs

- `improvement-plan` (string): Markdown improvement plan; empty when consent is missing.
- `blocking-questions` (string): Markdown list of blocking questions; empty when none.

<!-- agents-repo package version: 1.2.0 -->

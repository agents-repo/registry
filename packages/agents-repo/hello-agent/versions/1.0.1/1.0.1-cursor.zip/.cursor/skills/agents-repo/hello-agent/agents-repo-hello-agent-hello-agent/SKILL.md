---
name: agents-repo-hello-agent-hello-agent
description: >-
  Responds with a simple hello workflow Use when the user needs the
  agents-repo-hello-agent-hello-agent workflow.
---
# Overview

Responds with a simple hello workflow

## Responsibilities

- Primary responsibility placeholder
- Secondary responsibility placeholder

## Constraints

- Constraint or limitation placeholder

## Interaction Contract

Input: Describe expected input type or format
Output: Describe expected output type or format

<!-- agents-repo package version: 1.0.1 -->
